<?php
$username='----';
$password='---';

?>