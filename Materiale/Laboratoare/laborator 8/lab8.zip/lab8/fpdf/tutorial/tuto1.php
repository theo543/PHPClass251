<?php
require('../fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{

$this->SetTextColor(47,140,158);
$this->SetFont('Arial','',22);
$this->Cell(0,10,'S.C. Cubus Arts S.R.L.',0,1,'L');
$this->SetTextColor(0,0,0);
$this->SetFont('Arial','',10);
$this->Cell(37,4,'Nr. ord. reg. com. / an:',0,0,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'J32/508/2000',0,1,'L');
$this->SetFont('Arial','',10);
$this->Cell(8,4,'CIF:',0,0,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'RO 13548146',0,1,'L');
$this->SetFont('Arial','',10);
$this->Cell(13,4,'Adresa:',0,0,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'Strada Morii 198',0,1,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'892200 Lugojoara, jud. Timis, Romania',0,1,'L');
$this->SetFont('Arial','',10);
$this->Cell(14,4,'Telefon:',0,0,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'0368 409 233',0,1,'L');
$this->SetFont('Arial','',10);
$this->Cell(10,4,'Email:',0,0,'L');
$this->SetFont('Arial','B',10);
$this->Cell(0,4,'office@factureaza.ro',0,1,'L'); 
$this->SetFont('Arial','',10);
$this->Cell(9,4,'Site: ',0,0,'L');
$this->SetFont('Arial','B',10);
$this->SetLineWidth(0.6);
$this->Cell(26,4,'www.cubus.ro','B',1,'L',0,'https://www.cubus.ro');
$this->SetLineWidth(0.1);
$this->SetDrawColor(47,140,158);
$this->Cell(0,5,' ','B',1,'L');

$this->SetTextColor(47,140,158);
$this->Image('factura-logo.png', 155, 22, 30, 21);



	$this->Ln(20);
}

// Page footer
function Footer()
{
	// Position at 1.5 cm from bottom
$this->SetY(-25);
$centru=192;	
$this->SetDrawColor(47,140,158);
$this->SetTextColor(0,0,0);
$this->SetLineWidth(0.1);
$this->SetFont('Times','B',7);
$this->Cell($centru/3,5,'S.C. Cubus Arts S.R.L.','T',0,'L');
$this->Cell($centru/3,5,'Adresa: Strada Morii 198','T',0,'L');
$this->Cell($centru/3,5,'mail: office@factureaza.ro','T',1,'L');
$this->Cell($centru/3,1,'Nr. ord. reg. com. / an: J32/508/2000',0,0,'L');
$this->Cell($centru/3,1,'892200 Lugojoara, jud. Timis, Romania',0,0,'L');
$this->Cell($centru/3,1,'Site: www.cubus.ro',0,1,'L');
$this->Cell($centru/3,5,'CIF: RO 13548146','B',0,'L');
$this->Cell($centru/3,5,'Telefon: 0368 409 233','B',0,'L');
$this->Cell($centru/3,5,' ','B',1,'L');
$this->ln(3);

$this->SetTextColor(205,205,205);
$this->Cell($centru/3,5,'creat prin factureaza.ro',0,0,'L');

}
}


$pdf = new PDF('P','mm','A4');

//A4 => w:210 h: 297
$left=9;
$right=9;
$pdf->SetLeftMargin($left);
$pdf->SetRightMargin($right);
$centru=192;
$pdf->AddPage();


$pdf->SetFont('Times','',12);
for($i=1;$i<=40;$i++)
    $pdf->Cell(0,10,'Printing line number '.$i,0,1);



$pdf->Output();
?>
